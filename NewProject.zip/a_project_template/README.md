# BLANK AVR PROJECT FOLDER
>This folder was created by a command line sh script

    ./a_new_project <project_name>

>1. All .c and .h files are to be created in the src/ folder, 
>2. All .c and .h library source need to be referenced as a symlink in the src/ folder,
>3. Make file can be called as usual with make all, make clean or make flash,
>4. Setup the PROGRAMMER variable in Makefile to point to the correct USB device,
>5. There is a .gitignore file but the user needs to do a    
    a) git init  
    b) git add and   
    c) git commit
>6. NOTE that no provision for setting the lockbits in the device has been made yet in Makefile

## Very Important
There can be **_NO_** unused source files in the src/ folder! If there are the Makefile will try to compile and link then and then all kinds of errors crop up. Best to make a backups/ folder or something like that to keep unusef files in.

>Symbolic links is create with the  

    ln

>command. Generally my library sources lives in ~/Documents/Programming/AVR/MyLib/ folder. E.g adc.c & adc.h. So, from within the src folder issue the following command:  

><code>*DEPRICATED*</code> ln -s ~/Documents/Programming/AVR/MyLib/adc.h ~/Documents/Programming/AVR/BuildMake/src/adc.h

>and  
<CODE>*DECPRICATED*</code>
    ln -s ~/Documents/Programming/AVR/MyLib/adc.c ~/Documents/Programming/AVR/BuildMake/src/adc.c

>SINCE MY iMAC and MacBook-Pro has different User Account Names and different Home folder names I can not just use absoluter paths (i.e. ~/Documents/....), it **_must_** be relative. So, change to the source folder:

    cd src

>Then issue the soft link command using realtive paths:

    ln ../../MyLib/spi.h spi.h

>meaning that now src/spi.h points to MyLib that is a sub folder 2 levels up.
>
>As far as Make is concerned, these files then exist in the src/ folder.

(_This is a MARKDOWN formatted file_)


