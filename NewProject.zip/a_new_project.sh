#!/usr/bin/env bash
if [[ $# -eq 0 ]] ; then
    echo 'USAGE: setupProject <projectname>'
    exit 1
else
    cp -R a_project_template $1
fi
